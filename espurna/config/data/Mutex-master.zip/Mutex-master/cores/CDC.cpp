/* Stub for CDC.cpp */

#include <CDC.cpp>